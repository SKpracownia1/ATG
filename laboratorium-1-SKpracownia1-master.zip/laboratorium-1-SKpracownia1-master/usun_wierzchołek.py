#-*- coding: utf-8 -*-

def remove_vertex(graf,v):
    try:
        if int(v) not in graf:
	        print("wierzchołek nie istnieje")
    except ValueError:
	    print("wierzchołek nie istnieje")

    else:
        del graf[int(v)]
        for i in graf:
            try:
                graf[i].remove(int(v))
            except KeyError:
                continue
    return graf


graf={0:set([1,2]), 1:set([0,2]), 2:set([0,1]), 3:set([1,2])}
a=input("Podaj wierzchołek do usunięcia: ")
remove_vertex(graf,a)
