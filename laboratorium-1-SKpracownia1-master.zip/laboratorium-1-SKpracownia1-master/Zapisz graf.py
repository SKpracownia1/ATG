#-*- coding: utf-8 -*-

import sys

def data_check(d,typ,m):
	e=False
	if(typ==1):
		for i in d:
			try:
				if(int(i)<0):
					print("Wartości ujemne są niedozwolone")
					e=True
					break
			except ValueError:
				print("Wprowadzono błędny typ danych")	
				e=True
				break

	elif(typ==2):
		try:
			if(int(d)<0):
				print("Wartości ujemne są niedozwolone")
				e=True
		except ValueError:
			print("Wprowadzono błędny typ danych")	
			e=True
	return e

def input1():

	while (True):
		lista={}
		n=input("Podaj liczbę wierzchołków:")
		if(n=='q'):
			break
		if(data_check(n,2,0)==True):
			del lista
			continue
		print("Wprowadź listę sąsiedztwa:")
		for i in range (int(n)):
			x=input()
			if(x==''):
				lista[i]=[]
			elif(x=='q'):
				break
			else:
				lista[i]=x.split(" ")
			if(data_check(lista[i],1,n)==True):
				del lista
				return 0
		break
	return lista

def conv(lista):
	for i in lista:
		l=lista.get(i)
		lista[i]=set(l)
	return lista

def stopnie(graf):
	max_deg=0
	for i in graf:
		if(len(graf.get(i))>=max_deg):
			max_deg=len(graf.get(i))
		print("deg(v",i,")=",len(graf.get(i)))
	print("Stopień grafu:",max_deg)

while(True):
	graf=input1()
	if(graf!=0):
		graf=conv(graf)
		stopnie(graf)
		break
