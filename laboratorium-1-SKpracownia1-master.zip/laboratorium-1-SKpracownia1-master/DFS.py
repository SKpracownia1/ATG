#-*- coding: utf-8 -*-

graf={0:set([1,2]), 1:set([0,2]), 2:set([0,1]), 3:set([1,2])}

def dfs(graf, start):
    odwiedzone = set()
    stos = [start]
    while stos!=[]:
        w = stos.pop()
        if w not in odwiedzone:
            odwiedzone.add(w)
            stos.extend(graf[w] - odwiedzone)
    return odwiedzone

print(dfs(graf,0))


        



        

