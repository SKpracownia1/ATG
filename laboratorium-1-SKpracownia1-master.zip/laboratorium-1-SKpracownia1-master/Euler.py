#-*- coding: utf-8 -*-

def dfs(graf, start):
    odwiedzone = set()
    stos = [start]
    while stos!=[]:
        w = stos.pop()
        if w not in odwiedzone:
            odwiedzone.add(w)
            stos.extend(graf[w] - odwiedzone)
    return odwiedzone

def stopnie(graf):
    licznik=0
    for i in graf:
        if (len(graf.get(i))%2!=0):
            licznik+=1
    return licznik


graf={0: {1, 3}, 1: {0, 2}, 2: {1, 3}, 3: {0, 2, 1}}

if(len(dfs(graf,0))==len(graf)):
    spojny=True
    print("Graf jest spójny")
else:
    spojny=False
    print("Graf nie jest spójny")

licznik=stopnie(graf)
print("Liczba wierzchołków o nieparzystym stopniu:",licznik)

if(spojny==True and licznik==0):
    print("Graf jest Eulerowski")
elif(spojny==True and licznik<=2):
    print("Graf jest Pół-Eulerowski")
else:
    print("Graf nie jest Eulerowski")




        



        

